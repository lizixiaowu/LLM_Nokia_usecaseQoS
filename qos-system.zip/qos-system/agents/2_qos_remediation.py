import uvicorn
import json
from fastapi import FastAPI
from langgraph.graph import StateGraph, END
from langchain_google_genai import ChatGoogleGenerativeAI
from pydantic import BaseModel, Field
from typing import Dict, Any
import os
from models.a2a_models import A2AMessage, RemediationPlan
from .agent_card_generator import AGENT_CONFIGS, generate_agent_card
import time

# --- State Model for LangGraph ---
class GraphState(BaseModel):
    alarm_data: Dict[str, Any] = Field(default_factory=dict)
    topology: Dict[str, Any] = Field(default_factory=dict)
    plan: RemediationPlan = None
    error: str = None
    step: str = "START"

# --- LangGraph Node (using Gemini) ---
AGENT_NAME = "QoS Remediation Agent"
llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash", api_key=os.getenv("GEMINI_API_KEY"))

def analyze_and_plan(state: GraphState) -> GraphState:
    print(f"[{AGENT_NAME}] Step 1: Analyzing alarm and topology with Gemini.")
    alarm = state.alarm_data
    topology = state.topology

    # Prompt: Requesting structured JSON repair plan from Gemini
    prompt = f"""
    You are a network decision agent. Based on the following alarm data and network topology, formulate a high-level JSON remediation plan.
    Alarm Data: {json.dumps(alarm, indent=2)}
    Network Topology: {json.dumps(topology, indent=2)}

    The remediation goal is to reduce latency. Create a RemediationPlan JSON object containing actions to increase the QoS priority on the device interface.
    """
    
    # Use LLM to reason and generate the plan. We simulate a valid output here for stability.
    try:
        # Simulated structured plan based on LLM's reasoning
        plan_data = {
            "plan_id": f"PLAN-{alarm.get('alarm_id', 'Unknown')}",
            "device_id": topology.get('core_router', 'RTR-CORE'),
            "priority": 1,
            "actions": {
                "interface": topology.get('affected_interface', 'Unknown'),
                "new_qos_level": "priority_high",
                "reason": "LLM diagnosed bottleneck on core router interface."
            }
        }
        state.plan = RemediationPlan(**plan_data)
        state.step = "PLAN_GENERATED"
    except Exception as e:
        state.error = str(e)
        state.step = "ERROR"
        
    return state

# --- LangGraph Definition ---
workflow = StateGraph(GraphState)
workflow.add_node("analyze_plan", analyze_and_plan)
workflow.set_entry_point("analyze_plan")
workflow.add_edge("analyze_plan", END) 
app_graph = workflow.compile()

# --- FastAPI Wrapper (A2A Server) ---
CONFIG = AGENT_CONFIGS[AGENT_NAME]

app = FastAPI(title=f"{AGENT_NAME} A2A Server")

# 1. Agent Card Endpoint (Manually created for LangGraph)
card = generate_agent_card(AGENT_NAME, CONFIG["port"], CONFIG["description"], CONFIG["capability"], CONFIG["params"], CONFIG["returns"])
@app.get("/.well-known/agent.json")
async def get_agent_card():
    return card

# 2. A2A Message Handler
@app.post("/a2a")
async def handle_a2a_message(message: A2AMessage):
    if message.payload.get('capability') == CONFIG["capability"]:
        params = message.payload.get('params', {})
        
        # Start LangGraph process
        initial_state = GraphState(
            alarm_data=params.get("alarm_data", {}),
            topology=params.get("topology", {})
        )
        
        final_state_dict = app_graph.invoke(initial_state) # LangGraph returns a dictionary
        
        # FIX: Access the dictionary directly instead of treating it as a Pydantic object
        if final_state_dict.get('error'):
            return {"status": "failure", "error": final_state_dict['error']}
        
        # FIX: Use model_dump() for Pydantic V2 compatibility
        return {"status": "success", "result": {"remediation_plan": final_state_dict['plan'].model_dump()}}
    
    return {"status": "failure", "error": "Invalid capability."}

if __name__ == "__main__":
    print(f"Starting {AGENT_NAME} (LangGraph) on port {CONFIG['port']}...")
    uvicorn.run(app, host="localhost", port=CONFIG["port"])