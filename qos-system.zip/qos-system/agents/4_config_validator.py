import uvicorn
from .adk_base_agent import ADKA2ABaseAgent
from .agent_card_generator import AGENT_CONFIGS, generate_agent_card
from models.a2a_models import CLIConfig, ValidationResult
from langchain_google_genai import ChatGoogleGenerativeAI
from typing import Dict, Any
import os

AGENT_NAME = "Config Validation Agent"
CONFIG = AGENT_CONFIGS[AGENT_NAME]

class ConfigValidationAgent(ADKA2ABaseAgent):
    """ADK Dedicated Class for Configuration Validation (Quality Control)"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash", api_key=os.getenv("GEMINI_API_KEY"))

    def process_message(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        params = payload.get("params", {})
        cli_config_dict = params.get("cli_config")
        if not cli_config_dict:
            raise ValueError("Missing cli_config in payload.")
            
        cli_config = CLIConfig(**cli_config_dict)
        
        print(f"[{self.agent_name}] Validating CLI config using Gemini.")
        
        # Simulate LLM validation logic
        if "configure terminal" not in cli_config.cli_text:
            is_valid = False
            report = "Syntax Error: Missing 'configure terminal' entry command."
        else:
            # We assume it's valid if basic structure is present
            is_valid = True
            report = "Syntax check passed. Compliance check successful."
        
        validation_result = ValidationResult(
            is_valid=is_valid,
            report=report
        )

        return {"validation_result": validation_result.dict()}

card = generate_agent_card(AGENT_NAME, CONFIG["port"], CONFIG["description"], CONFIG["capability"], CONFIG["params"], CONFIG["returns"])
agent = ConfigValidationAgent(AGENT_NAME, "localhost", CONFIG["port"], card)

if __name__ == "__main__":
    print(f"Starting {AGENT_NAME} on port {CONFIG['port']}...")
    uvicorn.run(agent.app, host=agent.host, port=agent.port)