import uvicorn
from .adk_base_agent import ADKA2ABaseAgent
from .agent_card_generator import AGENT_CONFIGS, generate_agent_card
from models.a2a_models import RemediationPlan, CLIConfig
from langchain_google_genai import ChatGoogleGenerativeAI
from typing import Dict, Any
import os

AGENT_NAME = "Config Generation Agent"
CONFIG = AGENT_CONFIGS[AGENT_NAME]

class ConfigGenerationAgent(ADKA2ABaseAgent):
    """ADK Dedicated Class for Configuration Generation (Transformer)"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash", api_key=os.getenv("GEMINI_API_KEY"))

    def process_message(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        params = payload.get("params", {})
        remediation_plan_dict = params.get("remediation_plan")
        if not remediation_plan_dict:
            raise ValueError("Missing remediation_plan in payload.")
            
        remediation_plan = RemediationPlan(**remediation_plan_dict)
        
        print(f"[{self.agent_name}] Converting plan {remediation_plan.plan_id} to CLI text using Gemini.")
        
        # Simulate CLI configuration generation based on the plan
        device_id = remediation_plan.device_id
        interface_name = remediation_plan.actions.get('interface', 'Unknown Interface')
        qos_level = remediation_plan.actions.get('new_qos_level', 'default')

        cli_text = f"""
configure terminal
interface {interface_name}
  qos trust dscp
  service-policy output {qos_level}_policy
end
write memory
"""
        
        cli_config = CLIConfig(
            cli_text=cli_text,
            device_type="Cisco"
        )

        return {"cli_config": cli_config.dict()}

card = generate_agent_card(AGENT_NAME, CONFIG["port"], CONFIG["description"], CONFIG["capability"], CONFIG["params"], CONFIG["returns"])
agent = ConfigGenerationAgent(AGENT_NAME, "localhost", CONFIG["port"], card)

if __name__ == "__main__":
    print(f"Starting {AGENT_NAME} on port {CONFIG['port']}...")
    uvicorn.run(agent.app, host=agent.host, port=agent.port)